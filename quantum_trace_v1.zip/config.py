import os
from pathlib import Path

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"

for d in [DATA_DIR, REPORTS_DIR]:
    d.mkdir(exist_ok=True)

THREADS = int(os.getenv("QT_THREADS", "30"))
TIMEOUT = int(os.getenv("QT_TIMEOUT", "15"))
RETRIES = int(os.getenv("QT_RETRIES", "3"))
CHAIN_DEPTH = int(os.getenv("QT_CHAIN_DEPTH", "2"))

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:115.0) Gecko/20100101 Firefox/115.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/115.0.1901.183",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/109.0",
]

PROXIES = []
for p in ["HTTP_PROXY", "HTTPS_PROXY", "SOCKS5_PROXY"]:
    v = os.getenv(p, "")
    if v:
        PROXIES.append(v)

API_KEYS = {
    "shodan": os.getenv("SHODAN_KEY", ""),
    "virustotal": os.getenv("VT_KEY", ""),
    "hunter": os.getenv("HUNTER_KEY", ""),
    "telegram_bot": os.getenv("TG_BOT_TOKEN", ""),
    "github": os.getenv("GITHUB_KEY", ""),
    "ipinfo": os.getenv("IPINFO_KEY", ""),
    "abuseipdb": os.getenv("ABUSEIPDB_KEY", ""),
    "hibp": os.getenv("HIBP_KEY", ""),
    "censys_id": os.getenv("CENSYS_ID", ""),
    "censys_secret": os.getenv("CENSYS_SECRET", ""),
    "numverify": os.getenv("NUMVERIFY_KEY", ""),
    "securitytrails": os.getenv("ST_KEY", ""),
    "wigle": os.getenv("WIGLE_KEY", ""),
    "telegram_api_id": os.getenv("TG_API_ID", ""),
    "telegram_api_hash": os.getenv("TG_API_HASH", ""),
    "tor_proxy": os.getenv("TOR_PROXY", "socks5://127.0.0.1:9050"),
}

THEME = {
    "primary": "cyan",
    "success": "green",
    "warning": "yellow",
    "danger": "red",
    "info": "blue",
    "muted": "dim",
    "gold": "gold1",
}

SEARCH_MODES = {
    "1": {"name": "Phone", "icon": "📱", "accepts": ["phone"]},
    "2": {"name": "IP Address", "icon": "🗺️", "accepts": ["ip"]},
    "3": {"name": "Domain", "icon": "🌐", "accepts": ["domain"]},
    "4": {"name": "Email", "icon": "📧", "accepts": ["email"]},
    "5": {"name": "Username", "icon": "👤", "accepts": ["username"]},
    "6": {"name": "Telegram", "icon": "✈️", "accepts": ["telegram"]},
    "7": {"name": "Full Recon", "icon": "🔱", "accepts": ["phone", "ip", "domain", "email", "username", "telegram"]},
}
