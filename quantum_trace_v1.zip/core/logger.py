import logging
from pathlib import Path
from rich.logging import RichHandler

LOGS_DIR = Path(__file__).parent.parent / "data"
LOGS_DIR.mkdir(exist_ok=True)

def setup_logger(name="quantum_trace"):
    log = logging.getLogger(name)
    log.setLevel(logging.DEBUG)
    if log.handlers:
        return log
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s", datefmt="%H:%M:%S")
    fh = logging.FileHandler(LOGS_DIR / "qt.log", encoding="utf-8")
    fh.setLevel(logging.WARNING)
    fh.setFormatter(fmt)
    rh = RichHandler(rich_tracebacks=True, show_time=False, show_path=False)
    rh.setLevel(logging.INFO)
    log.addHandler(fh)
    log.addHandler(rh)
    return log
