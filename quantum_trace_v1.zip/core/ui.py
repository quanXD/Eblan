from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from config import SEARCH_MODES, THEME

class QuantumUI:
    def __init__(self):
        self.c = Console()

    def banner(self):
        art = r"""
   ____                  __        __   ______                 
  / __ \__  ______ _____/ /___  __/ /  /_  __/________ ______  
 / / / / / / / __ `/ __  / __ \/ / /    / / / ___/ __ `/ ___/  
/ /_/ / /_/ / /_/ / /_/ / /_/ / /_/    / / / /  / /_/ / /__    
\___/_/\_,_/\__,_/\__,_/\____/\__,_/   /_/ /_/   \__,_/\___/    
        """
        self.c.print(f"[bold {THEME['primary']}]{art}[/]")
        self.c.print(f"[bold {THEME['gold']}]QuantumTrace v1.0 // The God of OSINT[/]")
        self.c.print(f"[{THEME['muted']}]SQLite | Chain enrichment | Correlator | D3 graphs | 116+ modules[/]\n")

    def main_menu(self):
        items = ""
        for k, v in SEARCH_MODES.items():
            items += f"[{k}] {v['icon']} {v['name']}\n"
        items += "[8] ⚙️  Settings\n[9] 📊 History\n[0] 🚪 Exit"
        self.c.print(Panel.fit(items, title="[bold]SELECT TARGET TYPE[/bold]", border_style=THEME["primary"]))
        return self.c.input(f"[{THEME['primary']}]>> [/]").strip()

    def ask_target(self, mode_name):
        self.c.print(f"\n[{THEME['warning']}]Enter target for {mode_name} recon:[/]")
        return self.c.input(f"[{THEME['primary']}]Target >> [/]").strip()

    def result_table(self, title, rows, columns):
        if not rows:
            return
        t = Table(title=title, show_header=True, header_style=f"bold {THEME['primary']}")
        for col in columns:
            t.add_column(col)
        for row in rows:
            t.add_row(*[str(row.get(c, "")) for c in columns])
        self.c.print(t)

    def final_stats(self, stats, paths, correlations):
        self.c.print(f"\n[bold {THEME['gold']}]=== EXECUTION COMPLETE ===[/]")
        self.c.print(f"[{THEME['success']}]Modules run: {stats['modules']}[/]")
        self.c.print(f"[{THEME['success']}]Entities found: {stats['entities']}[/]")
        self.c.print(f"[{THEME['success']}]Elapsed: {stats['elapsed']}s[/]")
        self.c.print(f"[{THEME['info']}]🔗 Correlations found: {correlations}[/]")
        for label, path in paths.items():
            self.c.print(f"[{THEME['info']}]📁 {label}: {path}[/]")

    def alert(self, msg, level="info"):
        self.c.print(f"[{THEME.get(level, 'white')}]{msg}[/]")
