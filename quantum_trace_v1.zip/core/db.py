import sqlite3
import json
from pathlib import Path
from config import DATA_DIR

DB_PATH = DATA_DIR / "quantumtrace.db"

class QuantumDB:
    def __init__(self):
        self.conn = sqlite3.connect(str(DB_PATH))
        self.conn.row_factory = sqlite3.Row
        self._init_tables()

    def _init_tables(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target TEXT NOT NULL,
                target_type TEXT NOT NULL,
                mode TEXT NOT NULL,
                started TEXT,
                finished TEXT,
                stats TEXT
            );
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                module TEXT,
                entity_type TEXT,
                value TEXT,
                data TEXT,
                FOREIGN KEY(scan_id) REFERENCES scans(id)
            );
            CREATE TABLE IF NOT EXISTS correlations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                from_type TEXT,
                from_value TEXT,
                to_type TEXT,
                to_value TEXT,
                link_type TEXT,
                FOREIGN KEY(scan_id) REFERENCES scans(id)
            );
            CREATE INDEX IF NOT EXISTS idx_entities_scan ON entities(scan_id);
            CREATE INDEX IF NOT EXISTS idx_entities_value ON entities(value);
            CREATE INDEX IF NOT EXISTS idx_corr_scan ON correlations(scan_id);
        """)
        self.conn.commit()

    def new_scan(self, target, target_type, mode):
        c = self.conn.cursor()
        c.execute("INSERT INTO scans (target, target_type, mode, started) VALUES (?, ?, ?, datetime('now'))", (target, target_type, mode))
        self.conn.commit()
        return c.lastrowid

    def finish_scan(self, scan_id, stats):
        self.conn.execute("UPDATE scans SET finished=datetime('now'), stats=? WHERE id=?", (json.dumps(stats), scan_id))
        self.conn.commit()

    def add_entity(self, scan_id, module, entity_type, value, data):
        self.conn.execute("INSERT INTO entities (scan_id, module, entity_type, value, data) VALUES (?, ?, ?, ?, ?)", (scan_id, module, entity_type, value, json.dumps(data, ensure_ascii=False)))
        self.conn.commit()

    def add_correlation(self, scan_id, from_type, from_value, to_type, to_value, link_type):
        self.conn.execute("INSERT INTO correlations (scan_id, from_type, from_value, to_type, to_value, link_type) VALUES (?, ?, ?, ?, ?, ?)", (scan_id, from_type, from_value, to_type, to_value, link_type))
        self.conn.commit()

    def get_entities(self, scan_id, entity_type=None):
        if entity_type:
            c = self.conn.execute("SELECT * FROM entities WHERE scan_id=? AND entity_type=?", (scan_id, entity_type))
        else:
            c = self.conn.execute("SELECT * FROM entities WHERE scan_id=?", (scan_id,))
        return [dict(row) for row in c.fetchall()]

    def get_correlations(self, scan_id):
        c = self.conn.execute("SELECT * FROM correlations WHERE scan_id=?", (scan_id,))
        return [dict(row) for row in c.fetchall()]

    def get_scans(self):
        c = self.conn.execute("SELECT * FROM scans ORDER BY id DESC")
        return [dict(row) for row in c.fetchall()]
