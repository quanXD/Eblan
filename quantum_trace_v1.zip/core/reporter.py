import json
from pathlib import Path
from config import REPORTS_DIR
from core.utils import timestamp
from core.db import QuantumDB

class Reporter:
    def __init__(self, scan_id):
        self.scan_id = scan_id
        self.db = QuantumDB()

    def save_json(self, target, mode_name):
        path = REPORTS_DIR / f"qt_{mode_name.lower().replace(' ', '_')}_{target.replace('/', '_').replace('@', 'at')}_{timestamp()}.json"
        ents = self.db.get_entities(self.scan_id)
        corrs = self.db.get_correlations(self.scan_id)
        payload = {
            "target": target,
            "mode": mode_name,
            "entities": ents,
            "correlations": corrs,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        return path

    def save_html(self, target, mode_name):
        path = REPORTS_DIR / f"qt_{mode_name.lower().replace(' ', '_')}_{target.replace('/', '_').replace('@', 'at')}_{timestamp()}.html"
        ents = self.db.get_entities(self.scan_id)
        corrs = self.db.get_correlations(self.scan_id)
        html = self._build_html(target, mode_name, ents, corrs)
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        return path

    def _build_html(self, target, mode_name, ents, corrs):
        nodes = []
        links = []
        seen = set()
        colors = {"phone": "#00ff88", "email": "#4488ff", "domain": "#ffcc00", "ip": "#ff3366", "username": "#ffd700", "telegram": "#00d4ff"}
        for e in ents:
            val = e.get("value", "")
            et = e.get("entity_type", "unknown")
            if val not in seen:
                seen.add(val)
                nodes.append({"id": val, "group": et, "color": colors.get(et, "#888")})
        for c in corrs:
            fv = c.get("from_value", "")
            tv = c.get("to_value", "")
            lt = c.get("link_type", "link")
            if fv in seen and tv in seen:
                links.append({"source": fv, "target": tv, "label": lt})
        nodes_json = json.dumps(nodes)
        links_json = json.dumps(links)
        rows = ""
        for e in ents:
            data = json.loads(e.get("data", "{}"))
            rows += f"<tr><td>{e.get('module','')}</td><td>{e.get('entity_type','')}</td><td>{e.get('value','')}</td><td>{json.dumps(data, ensure_ascii=False)[:200]}</td></tr>"
        return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>QuantumTrace v1.0</title>
<script src="https://d3js.org/d3.v7.min.js"></script>
<style>body{{background:#0a0a0f;color:#e0e0e0;font-family:monospace;margin:0}}
h1{{color:#00d4ff;text-align:center}}h2{{color:#ffd700}}
#graph{{width:100%;height:500px;background:#111;border:1px solid #333}}
table{{border-collapse:collapse;width:98%;margin:10px auto}}
th{{background:#111;color:#00d4ff;padding:8px;border:1px solid #333}}
td{{border:1px solid #333;padding:6px;font-size:12px}}
.stats{{text-align:center;padding:20px;color:#888}}
</style></head>
<body><h1>QuantumTrace v1.0</h1><h2 style="text-align:center">{target} | {mode_name}</h2>
<div class="stats">Entities: {len(ents)} | Correlations: {len(corrs)}</div>
<div id="graph"></div>
<table><tr><th>Module</th><th>Type</th><th>Value</th><th>Data</th></tr>{rows}</table>
<script>
const nodes = {nodes_json};
const links = {links_json};
const svg = d3.select("#graph").append("svg").attr("width", "100%").attr("height", "100%").attr("viewBox", [0, 0, 1200, 500]);
const simulation = d3.forceSimulation(nodes).force("link", d3.forceLink(links).id(d => d.id).distance(100)).force("charge", d3.forceManyBody().strength(-300)).force("center", d3.forceCenter(600, 250));
const link = svg.append("g").selectAll("line").data(links).join("line").attr("stroke", "#555").attr("stroke-width", 2);
const node = svg.append("g").selectAll("g").data(nodes).join("g").call(d3.drag().on("start", dragstarted).on("drag", dragged).on("end", dragended));
node.append("circle").attr("r", 12).attr("fill", d => d.color).attr("stroke", "#fff").attr("stroke-width", 1.5);
node.append("text").text(d => d.id).attr("x", 16).attr("y", 4).attr("fill", "#e0e0e0").attr("font-size", "11px");
simulation.on("tick", () => {{link.attr("x1", d => d.source.x).attr("y1", d => d.source.y).attr("x2", d => d.target.x).attr("y2", d => d.target.y); node.attr("transform", d => `translate(${{d.x}},${{d.y}})`);}});
function dragstarted(event, d) {{if (!event.active) simulation.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y;}}
function dragged(event, d) {{d.fx = event.x; d.fy = event.y;}}
function dragended(event, d) {{if (!event.active) simulation.alphaTarget(0); d.fx = null; d.fy = null;}}
</script></body></html>"""
