import random
import hashlib
import re
import ipaddress
import asyncio
from datetime import datetime

def get_ua():
    from config import USER_AGENTS
    return random.choice(USER_AGENTS)

def get_proxy():
    from config import PROXIES
    return random.choice(PROXIES) if PROXIES else None

def md5(val):
    return hashlib.md5(str(val).encode()).hexdigest()

def sha1(val):
    return hashlib.sha1(str(val).encode()).hexdigest()

def is_ip(val):
    try:
        ipaddress.ip_address(val)
        return True
    except:
        return False

def is_email(val):
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", str(val)))

def is_phone(val):
    return bool(re.match(r"^[\+]?[0-9\s\-\(\)]{7,20}$", str(val)))

def norm_domain(val):
    v = str(val).lower().strip()
    v = v.replace("http://", "").replace("https://", "").strip("/")
    return v

def norm_phone(val):
    return re.sub(r"[^0-9+]", "", str(val))

def timestamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def ts_human():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def detect_type(val):
    if is_phone(val):
        return "phone"
    if is_email(val):
        return "email"
    if is_ip(val):
        return "ip"
    if val.startswith("@") or val.startswith("t.me/"):
        return "telegram"
    if "." in val and not val.startswith("http") and "/" not in val:
        return "domain"
    return "username"

async def fetch(session, url, headers=None, proxy=None, timeout=15, retries=3):
    from aiohttp_socks import ProxyConnector
    for attempt in range(retries):
        try:
            if proxy and proxy.startswith("socks"):
                connector = ProxyConnector.from_url(proxy)
                async with aiohttp.ClientSession(connector=connector) as s:
                    async with s.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                        return r.status, await r.text()
            else:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout), proxy=proxy) as r:
                    return r.status, await r.text()
        except Exception:
            if attempt < retries - 1:
                await asyncio.sleep(2 ** attempt)
    return 0, ""
