import asyncio
import importlib.util
import json
from pathlib import Path
from typing import Dict, List, Any
from config import SEARCH_MODES, THREADS, CHAIN_DEPTH
from core.logger import setup_logger
from core.utils import timestamp, detect_type
from core.db import QuantumDB

log = setup_logger()

class QuantumEngine:
    def __init__(self):
        self.results: Dict[str, List[Dict]] = {}
        self.stats = {"entities": 0, "modules": 0, "elapsed": 0.0}
        self.modules = {}
        self.db = QuantumDB()
        self.scan_id = None
        self._load_modules()

    def _load_modules(self):
        d = Path(__file__).parent.parent / "modules"
        for f in d.glob("*.py"):
            if f.name.startswith("_"):
                continue
            try:
                spec = importlib.util.spec_from_file_location(f"modules.{f.stem}", f)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                if hasattr(mod, "Module"):
                    self.modules[f.stem] = mod.Module()
            except Exception as e:
                log.warning(f"Load fail {f.stem}: {e}")

    async def run_module(self, name: str, target: str) -> List[Dict]:
        mod = self.modules.get(name)
        if not mod:
            return []
        try:
            result = await mod.run(target)
            self.stats["modules"] += 1
            if isinstance(result, list):
                self.stats["entities"] += len(result)
                for item in result:
                    if isinstance(item, dict):
                        et = item.get("_entity_type", mod.category)
                        ev = item.get("_entity_value", target)
                        self.db.add_entity(self.scan_id, name, et, ev, item)
            return result
        except Exception as e:
            log.error(f"Run fail {name}: {e}")
            return []

    async def run_mode(self, mode_key: str, target: str) -> Dict[str, Any]:
        import time
        start = time.time()
        mode = SEARCH_MODES.get(mode_key)
        if not mode:
            return {}
        target_type = detect_type(target)
        self.scan_id = self.db.new_scan(target, target_type, mode["name"])
        accepted = [n for n, m in self.modules.items() if target_type in getattr(m, "accepts", [])]
        if mode_key == "7":
            to_run = accepted
        else:
            to_run = accepted
        semaphore = asyncio.Semaphore(THREADS)

        async def bounded(m):
            async with semaphore:
                return m, await self.run_module(m, target)

        tasks = [bounded(m) for m in to_run]
        raw = await asyncio.gather(*tasks)
        self.stats["elapsed"] = round(time.time() - start, 2)
        for name, data in raw:
            self.results[name] = data

        if CHAIN_DEPTH > 0:
            await self._chain_enrich(target, target_type, CHAIN_DEPTH)

        self._correlate()
        self.db.finish_scan(self.scan_id, self.stats)
        return self.results

    async def _chain_enrich(self, target: str, target_type: str, depth: int):
        if depth <= 0:
            return
        discovered = {}
        for mod_results in self.results.values():
            if not isinstance(mod_results, list):
                continue
            for item in mod_results:
                if not isinstance(item, dict):
                    continue
                for k, v in item.items():
                    if k in ("email", "domain", "ip", "phone", "username") and v and v != target:
                        t = detect_type(v)
                        if t not in discovered:
                            discovered[t] = set()
                        discovered[t].add(v)
        for dtype, values in discovered.items():
            for val in values:
                mods = [n for n, m in self.modules.items() if dtype in getattr(m, "accepts", [])]
                for m in mods[:5]:
                    res = await self.run_module(m, val)
                    if res:
                        self.results[f"{m}_chain"] = res

    def _correlate(self):
        ents = self.db.get_entities(self.scan_id)
        emails = [e for e in ents if e["entity_type"] == "email"]
        domains = [e for e in ents if e["entity_type"] == "domain"]
        ips = [e for e in ents if e["entity_type"] == "ip"]
        for e in emails:
            d = e["value"].split("@")[1] if "@" in e["value"] else None
            if d:
                for dom in domains:
                    if dom["value"] == d:
                        self.db.add_correlation(self.scan_id, "email", e["value"], "domain", d, "mx_domain")
        for dom in domains:
            try:
                data = json.loads(dom["data"])
                for item in data if isinstance(data, list) else [data]:
                    if item.get("type") == "A":
                        for ip_ent in ips:
                            if ip_ent["value"] == item.get("value"):
                                self.db.add_correlation(self.scan_id, "domain", dom["value"], "ip", item["value"], "dns_a")
            except:
                pass
