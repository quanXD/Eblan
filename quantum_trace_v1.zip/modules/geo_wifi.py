from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_wifi"
    category = "geo"
    accepts = ["wifi"]

    async def run(self, target):
        return [{"_entity_type": "wifi", "_entity_value": target, "target": target, "type": "wifi", "ssid": "N/A", "location": "N/A", "source": "wigle"}]
