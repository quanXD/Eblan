import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "tg_bot"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = target.replace("@", "").replace("t.me/", "")
        url = f"https://t.me/{u}"
        result = {
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "type": "bot",
            "url": url,
            "exists": "Unknown",
            "name": "N/A",
            "description": "N/A",
        }
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    if "bot" in text.lower() and "tgme_page_title" in text:
                        result["exists"] = "Yes"
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        if m:
                            result["name"] = m.group(1).strip()
        except:
            pass
        return [result]
