import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "email_github"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        key = API_KEYS.get("github", "")
        if key:
            try:
                headers = {"Authorization": f"token {key}", "User-Agent": get_ua()}
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://api.github.com/search/users?q={target}+in:email", headers=headers, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        items = d.get("items", [])
                        if items:
                            return [{
                                "_entity_type": "username",
                                "_entity_value": items[0].get("login", "N/A"),
                                "email": target,
                                "github_user": items[0].get("login", "N/A"),
                                "github_url": items[0].get("html_url", "N/A"),
                                "repos": "See profile",
                                "source": "github_api",
                            }]
            except:
                pass
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "github_user": "N/A",
            "github_url": "N/A",
            "repos": "N/A",
            "source": "no_api_key",
        }]
