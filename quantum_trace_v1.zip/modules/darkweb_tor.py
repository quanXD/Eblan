from modules.base import BaseModule

class Module(BaseModule):
    name = "darkweb_tor"
    category = "darkweb"
    accepts = ["ip", "domain", "email", "username"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "target": target, "tor_exit": "N/A", "darkweb_mentions": "N/A", "source": "darkweb"}]
