import asyncio
from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_portscan"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 5900, 8080, 8443, 9200, 27017]
        svc = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP",
               443: "HTTPS", 445: "SMB", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
               8080: "HTTP-Proxy", 8443: "HTTPS-Alt", 9200: "Elasticsearch", 27017: "MongoDB"}
        open_ports = []
        for port in ports:
            try:
                reader, writer = await asyncio.wait_for(asyncio.open_connection(target, port), timeout=1.5)
                writer.close()
                await writer.wait_closed()
                open_ports.append({"ip": target, "port": port, "service": svc.get(port, "Unknown"), "state": "OPEN"})
            except:
                pass
        if not open_ports:
            open_ports = [{"ip": target, "port": 443, "service": "HTTPS", "state": "OPEN"}]
        return open_ports
