from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_ip"
    category = "geo"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "target": target, "type": "ip", "country": "N/A", "city": "N/A", "lat": "N/A", "lon": "N/A", "isp": "N/A", "source": "geo"}]
