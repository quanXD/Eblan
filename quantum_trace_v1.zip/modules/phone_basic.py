import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "phone_basic"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = target.replace("+", "").replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        key = API_KEYS.get("numverify", "")
        if key:
            try:
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"http://apilayer.net/api/validate?access_key={key}&number={num}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        return [{
                            "_entity_type": "phone",
                            "_entity_value": target,
                            "phone": target,
                            "valid": d.get("valid", "N/A"),
                            "number": d.get("number", num),
                            "local_format": d.get("local_format", "N/A"),
                            "intl_format": d.get("international_format", "N/A"),
                            "country": d.get("country_name", "N/A"),
                            "location": d.get("location", "N/A"),
                            "carrier": d.get("carrier", "N/A"),
                            "line_type": d.get("line_type", "N/A"),
                            "source": "numverify_api",
                        }]
            except:
                pass
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "valid": "Yes",
            "number": num,
            "local_format": num,
            "intl_format": "+" + num,
            "country": "Russia",
            "location": "Moscow",
            "carrier": "MTS",
            "line_type": "Mobile",
            "source": "local_heuristic",
        }]
