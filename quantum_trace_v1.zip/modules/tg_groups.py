from modules.base import BaseModule

class Module(BaseModule):
    name = "tg_groups"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "public_groups": "Requires Telegram MTProto or bot token",
            "method": "mtproto",
            "note": "Use tg_user first to verify existence",
        }]
