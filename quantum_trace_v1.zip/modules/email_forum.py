from modules.base import BaseModule

class Module(BaseModule):
    name = "email_forum"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "reddit": "N/A",
            "hackernews": "N/A",
            "quora": "N/A",
            "stackoverflow": "N/A",
            "forums": "N/A",
        }]
