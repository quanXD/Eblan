from modules.base import BaseModule

class Module(BaseModule):
    name = "whois_ip"
    category = "whois"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "target": target, "type": "ip", "netrange": "N/A", "org": "N/A", "country": "N/A", "abuse": "N/A", "source": "whois"}]
