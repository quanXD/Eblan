import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "ip_abuse"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        key = API_KEYS.get("abuseipdb", "")
        if key:
            try:
                headers = {"Key": key, "Accept": "application/json", "User-Agent": get_ua()}
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://api.abuseipdb.com/api/v2/check?ipAddress={target}", headers=headers, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        data = d.get("data", {})
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "abuse_score": data.get("abuseConfidencePercentage", "N/A"),
                            "country": data.get("countryCode", "N/A"),
                            "isp": data.get("isp", "N/A"),
                            "reports": data.get("totalReports", 0),
                            "last_reported": data.get("lastReportedAt", "N/A")[:10] if data.get("lastReportedAt") else "Never",
                            "source": "abuseipdb_api",
                        }]
            except:
                pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "abuse_score": "N/A",
            "country": "N/A",
            "isp": "N/A",
            "reports": "N/A",
            "last_reported": "N/A",
            "source": "no_api_key",
        }]
