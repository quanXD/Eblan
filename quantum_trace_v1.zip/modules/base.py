import abc
from typing import List, Dict, Any

class BaseModule(abc.ABC):
    name = "base"
    category = "general"
    accepts = []

    @abc.abstractmethod
    async def run(self, target: str) -> List[Dict[str, Any]]:
        pass
