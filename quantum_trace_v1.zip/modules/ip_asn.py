import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "ip_asn"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        try:
            async with aiohttp.ClientSession() as s:
                status, text = await fetch(s, f"https://api.hackertarget.com/aslookup/?q={target}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if status == 200:
                    lines = text.strip().split("\n")
                    if lines and "Error" not in text:
                        parts = lines[0].split(",")
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "asn": parts[0] if len(parts) > 0 else "N/A",
                            "as_name": parts[1] if len(parts) > 1 else "N/A",
                            "range": parts[2] if len(parts) > 2 else "N/A",
                            "country": parts[3] if len(parts) > 3 else "N/A",
                            "source": "hackertarget",
                        }]
        except:
            pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "asn": "N/A",
            "as_name": "N/A",
            "range": "N/A",
            "country": "N/A",
            "source": "failed",
        }]
