import ssl
import socket
from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_ssl"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((target, 443), timeout=5) as sock:
                with ctx.wrap_socket(sock, server_hostname=target) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    version = ssock.version()
                    san = ", ".join([x[1] for x in cert.get("subjectAltName", [])]) if cert.get("subjectAltName") else "N/A"
                    return [{
                        "_entity_type": "domain",
                        "_entity_value": target,
                        "domain": target,
                        "subject": str(cert.get("subject", "N/A")),
                        "issuer": str(cert.get("issuer", "N/A")),
                        "not_after": str(cert.get("notAfter", "N/A")),
                        "not_before": str(cert.get("notBefore", "N/A")),
                        "san": san,
                        "cipher": str(cipher[0]) if cipher else "N/A",
                        "tls_version": version,
                        "source": "ssl_handshake",
                    }]
        except:
            return [{
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "subject": "N/A",
                "issuer": "N/A",
                "not_after": "N/A",
                "not_before": "N/A",
                "san": "N/A",
                "cipher": "N/A",
                "tls_version": "N/A",
                "source": "failed",
            }]
