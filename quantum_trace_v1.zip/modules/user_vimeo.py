import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "user_vimeo"
    category = "username"
    accepts = ["username"]

    async def run(self, target):
        url = "https://vimeo.com/{u}".format(u=target)
        status = "FOUND"
        extra = "Profile accessible"
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 404:
                    status = "NOT FOUND"
                    extra = "404 response"
                elif st == 403:
                    status = "BLOCKED"
                    extra = "403 Forbidden"
                elif st == 200:
                    if "not found" in text.lower() or "does not exist" in text.lower() or "page not found" in text.lower():
                        status = "NOT FOUND"
                        extra = "Page indicates no user"
        except:
            pass
        return [{
            "_entity_type": "username",
            "_entity_value": target,
            "username": target,
            "platform": "vimeo",
            "url": url,
            "status": status,
            "extra": extra,
        }]
