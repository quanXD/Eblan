from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_history"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "first_seen": "N/A",
            "last_changed": "N/A",
            "changes": "N/A",
            "previous_ips": "N/A",
        }]
