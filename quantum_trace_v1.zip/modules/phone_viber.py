from modules.base import BaseModule

class Module(BaseModule):
    name = "phone_viber"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "viber": "Not found",
            "status": "Unregistered or hidden",
            "source": "check",
        }]
