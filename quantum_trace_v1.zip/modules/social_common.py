from modules.base import BaseModule

class Module(BaseModule):
    name = "social_common"
    category = "social"
    accepts = ["username", "email"]

    async def run(self, target):
        return [{"_entity_type": "username", "_entity_value": target, "target": target, "common_groups": "N/A", "shared_interests": "N/A", "method": "heuristic", "source": "social"}]
