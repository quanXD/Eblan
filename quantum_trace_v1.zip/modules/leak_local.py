from modules.base import BaseModule

class Module(BaseModule):
    name = "leak_local"
    category = "leak"
    accepts = ["email", "username", "phone"]

    async def run(self, target):
        return [{"_entity_type": "email", "_entity_value": target, "target": target, "matches": 0, "note": "No local database configured", "source": "local"}]
