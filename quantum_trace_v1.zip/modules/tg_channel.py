import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "tg_channel"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = target.replace("@", "").replace("t.me/", "")
        url = f"https://t.me/{u}"
        result = {
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "type": "channel",
            "url": url,
            "exists": "Unknown",
            "subscribers": "N/A",
            "title": "N/A",
            "description": "N/A",
        }
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    if "tgme_page_extra" in text:
                        result["exists"] = "Yes"
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        if m:
                            result["title"] = m.group(1).strip()
                        m2 = re.search(r'tgme_page_extra[^>]*>([^<]+)</div>', text)
                        if m2:
                            result["subscribers"] = m2.group(1).strip()
        except:
            pass
        return [result]
