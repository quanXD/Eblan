from modules.base import BaseModule

class Module(BaseModule):
    name = "email_social"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "twitter": "N/A",
            "instagram": "N/A",
            "facebook": "N/A",
            "linkedin": "N/A",
            "pinterest": "N/A",
            "gravatar": "N/A",
        }]
