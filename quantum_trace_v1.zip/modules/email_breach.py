import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "email_breach"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        key = API_KEYS.get("hibp", "")
        if key:
            try:
                headers = {"hibp-api-key": key, "User-Agent": "QuantumTrace"}
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://haveibeenpwned.com/api/v3/breachedaccount/{target}", headers=headers, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        return [{
                            "_entity_type": "email",
                            "_entity_value": target,
                            "email": target,
                            "breaches": len(d),
                            "names": ", ".join([x.get("Name", "") for x in d[:5]]),
                            "severity": "CRITICAL" if len(d) > 2 else "HIGH",
                            "source": "hibp_api",
                        }]
                    elif status == 404:
                        return [{"_entity_type": "email", "_entity_value": target, "email": target, "breaches": 0, "names": "None", "severity": "CLEAN", "source": "hibp_api"}]
            except:
                pass
        return [{"_entity_type": "email", "_entity_value": target, "email": target, "breaches": "N/A", "names": "N/A", "severity": "N/A", "source": "no_api_key"}]
