from modules.base import BaseModule

class Module(BaseModule):
    name = "iot_search"
    category = "iot"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "target": target, "iot_devices": "N/A", "webcam": "N/A", "router": "N/A", "source": "iot"}]
