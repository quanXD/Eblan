from modules.base import BaseModule

class Module(BaseModule):
    name = "tg_forward"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "forward_analysis": "Requires MTProto access",
            "shared_channels": "N/A",
            "forward_sources": "N/A",
            "method": "mtproto",
        }]
