import json
from pathlib import Path
from modules.base import BaseModule
from config import REPORTS_DIR
from core.utils import timestamp

class Module(BaseModule):
    name = "report_generator"
    category = "report"
    accepts = ["phone", "ip", "domain", "email", "username", "telegram"]

    async def run(self, target):
        path = REPORTS_DIR / f"qt_summary_{timestamp()}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"target": target, "status": "report_generated"}, f, indent=2)
        return [{"_entity_type": "report", "_entity_value": target, "target": target, "report": str(path), "status": "saved", "source": "report"}]
