from modules.base import BaseModule

class Module(BaseModule):
    name = "tech_stack"
    category = "tech"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "target": target, "server": "N/A", "cms": "N/A", "frameworks": "N/A", "analytics": "N/A", "source": "tech"}]
