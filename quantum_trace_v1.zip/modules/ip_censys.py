import aiohttp
import base64
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "ip_censys"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        cid = API_KEYS.get("censys_id", "")
        csec = API_KEYS.get("censys_secret", "")
        if cid and csec:
            try:
                auth = base64.b64encode(f"{cid}:{csec}".encode()).decode()
                headers = {"Authorization": f"Basic {auth}", "User-Agent": get_ua()}
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://search.censys.io/api/v2/hosts/{target}", headers=headers, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        res = d.get("result", {})
                        svcs = res.get("services", [])
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "services": ", ".join([f"{s.get('port')}/{s.get('service_name')}" for s in svcs[:5]]),
                            "os": res.get("operating_system", {}).get("product", "N/A"),
                            "source": "censys_api",
                        }]
            except:
                pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "services": "N/A",
            "os": "N/A",
            "source": "no_api_key",
        }]
