from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_bgp"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "asn": "N/A",
            "as_path": "N/A",
            "prefix": "N/A",
            "upstream": "N/A",
            "peers": "N/A",
            "source": "bgp.he.net",
        }]
