from modules.base import BaseModule

class Module(BaseModule):
    name = "metadata_doc"
    category = "metadata"
    accepts = ["url"]

    async def run(self, target):
        return [{"_entity_type": "url", "_entity_value": target, "target": target, "type": "doc", "author": "N/A", "company": "N/A", "last_modified_by": "N/A", "created": "N/A", "source": "metadata"}]
