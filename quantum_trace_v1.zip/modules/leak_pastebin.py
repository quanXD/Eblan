from modules.base import BaseModule

class Module(BaseModule):
    name = "leak_pastebin"
    category = "leak"
    accepts = ["email", "username"]

    async def run(self, target):
        return [{"_entity_type": "email", "_entity_value": target, "target": target, "pastes": "N/A", "exposed": "N/A", "severity": "N/A", "source": "no_api_key"}]
