from modules.base import BaseModule

class Module(BaseModule):
    name = "darkweb_paste"
    category = "darkweb"
    accepts = ["email", "username"]

    async def run(self, target):
        return [{"_entity_type": "email", "_entity_value": target, "target": target, "dark_pastes": "N/A", "source": "darkweb"}]
