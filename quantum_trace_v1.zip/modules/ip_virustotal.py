import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "ip_virustotal"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        key = API_KEYS.get("virustotal", "")
        if key:
            try:
                headers = {"x-apikey": key, "User-Agent": get_ua()}
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://www.virustotal.com/api/v3/ip_addresses/{target}", headers=headers, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        attr = d.get("data", {}).get("attributes", {})
                        stats = attr.get("last_analysis_stats", {})
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "malicious": stats.get("malicious", 0),
                            "suspicious": stats.get("suspicious", 0),
                            "harmless": stats.get("harmless", 0),
                            "reputation": attr.get("reputation", "N/A"),
                            "country": attr.get("country", "N/A"),
                            "owner": attr.get("as_owner", "N/A"),
                            "source": "virustotal_api",
                        }]
            except:
                pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "malicious": "N/A",
            "suspicious": "N/A",
            "harmless": "N/A",
            "reputation": "N/A",
            "country": "N/A",
            "owner": "N/A",
            "source": "no_api_key",
        }]
