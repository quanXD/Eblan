import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "tg_username"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = target.replace("@", "").replace("t.me/", "")
        url = f"https://t.me/{u}"
        result = {
            "_entity_type": "telegram",
            "_entity_value": target,
            "username": target,
            "url": url,
            "exists": "Unknown",
            "name": "N/A",
            "type": "Unknown",
        }
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    if "tgme_page_title" in text:
                        result["exists"] = "Yes"
                        if "subscriber" in text.lower() or "member" in text.lower():
                            result["type"] = "Channel/Group"
                        else:
                            result["type"] = "User"
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        if m:
                            result["name"] = m.group(1).strip()
                    else:
                        result["exists"] = "No"
        except:
            pass
        return [result]
