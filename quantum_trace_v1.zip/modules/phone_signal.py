from modules.base import BaseModule

class Module(BaseModule):
    name = "phone_signal"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "signal": "Not registered",
            "safety_number": "N/A",
            "source": "check",
        }]
