from modules.base import BaseModule

class Module(BaseModule):
    name = "cve_search"
    category = "cve"
    accepts = ["ip", "domain"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "target": target, "cves": "N/A", "severity": "N/A", "source": "nvd"}]
