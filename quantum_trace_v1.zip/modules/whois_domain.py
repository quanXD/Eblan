from modules.base import BaseModule

class Module(BaseModule):
    name = "whois_domain"
    category = "whois"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "target": target, "type": "domain", "registrar": "N/A", "created": "N/A", "expires": "N/A", "status": "N/A", "source": "whois"}]
