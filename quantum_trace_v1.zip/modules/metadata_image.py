from modules.base import BaseModule

class Module(BaseModule):
    name = "metadata_image"
    category = "metadata"
    accepts = ["url"]

    async def run(self, target):
        return [{"_entity_type": "url", "_entity_value": target, "target": target, "type": "image", "camera": "N/A", "gps": "N/A", "date": "N/A", "software": "N/A", "source": "metadata"}]
