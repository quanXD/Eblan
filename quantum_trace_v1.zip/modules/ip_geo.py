import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "ip_geo"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        key = API_KEYS.get("ipinfo", "")
        if key:
            try:
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://ipinfo.io/{target}/json?token={key}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "country": d.get("country", "N/A"),
                            "region": d.get("region", "N/A"),
                            "city": d.get("city", "N/A"),
                            "zip": d.get("postal", "N/A"),
                            "lat": str(d.get("loc", "").split(",")[0]) if d.get("loc") else "N/A",
                            "lon": str(d.get("loc", "").split(",")[1]) if d.get("loc") else "N/A",
                            "isp": d.get("org", "N/A"),
                            "timezone": d.get("timezone", "N/A"),
                            "source": "ipinfo_api",
                        }]
            except:
                pass
        try:
            async with aiohttp.ClientSession() as s:
                status, text = await fetch(s, f"http://ip-api.com/json/{target}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if status == 200:
                    import json
                    d = json.loads(text)
                    return [{
                        "_entity_type": "ip",
                        "_entity_value": target,
                        "ip": target,
                        "country": d.get("country", "N/A"),
                        "region": d.get("regionName", "N/A"),
                        "city": d.get("city", "N/A"),
                        "zip": d.get("zip", "N/A"),
                        "lat": str(d.get("lat", "N/A")),
                        "lon": str(d.get("lon", "N/A")),
                        "isp": d.get("isp", "N/A"),
                        "timezone": d.get("timezone", "N/A"),
                        "source": "ip-api.com",
                    }]
        except:
            pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "country": "N/A",
            "region": "N/A",
            "city": "N/A",
            "zip": "N/A",
            "lat": "N/A",
            "lon": "N/A",
            "isp": "N/A",
            "timezone": "N/A",
            "source": "failed",
        }]
