from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_exif"
    category = "geo"
    accepts = ["url"]

    async def run(self, target):
        return [{"_entity_type": "url", "_entity_value": target, "target": target, "type": "exif", "gps": "N/A", "camera": "N/A", "date": "N/A", "source": "exif"}]
