import aiohttp
from bs4 import BeautifulSoup
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "domain_tech"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        try:
            async with aiohttp.ClientSession() as s:
                status, text = await fetch(s, f"https://{target}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if status == 200:
                    soup = BeautifulSoup(text, "html.parser")
                    server = "Unknown"
                    powered = "Unknown"
                    cms = "WordPress" if "wp-content" in text else "Unknown"
                    title = soup.title.string if soup.title else "N/A"
                    frameworks = []
                    if "react" in text.lower():
                        frameworks.append("React")
                    if "jquery" in text.lower():
                        frameworks.append("jQuery")
                    if "bootstrap" in text.lower():
                        frameworks.append("Bootstrap")
                    if "vue" in text.lower():
                        frameworks.append("Vue")
                    if "angular" in text.lower():
                        frameworks.append("Angular")
                    return [{
                        "_entity_type": "domain",
                        "_entity_value": target,
                        "domain": target,
                        "server": server,
                        "powered_by": powered,
                        "cms": cms,
                        "title": title,
                        "frameworks": ", ".join(frameworks) if frameworks else "None",
                        "source": "http_scan",
                    }]
        except:
            pass
        return [{
            "_entity_type": "domain",
            "_entity_value": target,
            "domain": target,
            "server": "N/A",
            "powered_by": "N/A",
            "cms": "N/A",
            "title": "N/A",
            "frameworks": "N/A",
            "source": "failed",
        }]
