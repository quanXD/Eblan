from modules.base import BaseModule

class Module(BaseModule):
    name = "whois_asn"
    category = "whois"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "target": target, "type": "asn", "asn": "N/A", "as_name": "N/A", "country": "N/A", "source": "whois"}]
