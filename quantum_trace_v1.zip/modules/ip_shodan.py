import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "ip_shodan"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        key = API_KEYS.get("shodan", "")
        if key:
            try:
                async with aiohttp.ClientSession() as s:
                    status, text = await fetch(s, f"https://api.shodan.io/shodan/host/{target}?key={key}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                    if status == 200:
                        import json
                        d = json.loads(text)
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "tags": ", ".join(d.get("tags", [])[:5]),
                            "ports": ", ".join(str(p) for p in d.get("ports", [])[:8]),
                            "hostnames": ", ".join(d.get("hostnames", [])[:3]),
                            "isp": d.get("isp", "N/A"),
                            "os": d.get("os", "N/A"),
                            "last_update": d.get("last_update", "N/A")[:10],
                            "source": "shodan_api",
                        }]
            except:
                pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "tags": "N/A",
            "ports": "N/A",
            "hostnames": "N/A",
            "isp": "N/A",
            "os": "N/A",
            "last_update": "N/A",
            "source": "no_api_key",
        }]
