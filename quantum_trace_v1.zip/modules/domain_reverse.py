from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_reverse"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        return [{
            "_entity_type": "domain",
            "_entity_value": target,
            "domain": target,
            "same_ip_domains": "N/A",
            "shared_ns": "N/A",
            "shared_mx": "N/A",
            "related_domains": "N/A",
        }]
