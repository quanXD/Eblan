import hashlib
import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "email_gravatar"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        h = hashlib.md5(target.lower().encode()).hexdigest()
        url = f"https://www.gravatar.com/avatar/{h}?d=404"
        try:
            async with aiohttp.ClientSession() as s:
                status, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                st = "Found" if status == 200 else "Not found"
                return [{
                    "_entity_type": "email",
                    "_entity_value": target,
                    "email": target,
                    "gravatar_hash": h,
                    "gravatar_url": f"https://www.gravatar.com/avatar/{h}",
                    "status": st,
                    "profile": f"https://www.gravatar.com/{h}" if status == 200 else "N/A",
                    "source": "gravatar_api",
                }]
        except:
            return [{
                "_entity_type": "email",
                "_entity_value": target,
                "email": target,
                "gravatar_hash": h,
                "gravatar_url": f"https://www.gravatar.com/avatar/{h}",
                "status": "Check failed",
                "profile": "N/A",
                "source": "gravatar_api",
            }]
