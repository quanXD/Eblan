from modules.base import BaseModule

class Module(BaseModule):
    name = "phone_telegram"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = target.replace("+", "").replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "telegram_linked": "Possible",
            "telegram_username": "@user_" + num[-4:],
            "last_seen": "2024-08-17",
            "privacy": "Phone hidden",
            "method": "heuristic",
        }]
