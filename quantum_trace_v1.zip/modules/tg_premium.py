import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "tg_premium"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = target.replace("@", "").replace("t.me/", "")
        url = f"https://t.me/{u}"
        result = {
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "premium": "Unknown",
            "badge": "N/A",
            "url": url,
        }
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    if " Premium" in text or "premium badge" in text.lower():
                        result["premium"] = "Yes"
                    elif "tgme_page_title" in text:
                        result["premium"] = "No"
        except:
            pass
        return [result]
