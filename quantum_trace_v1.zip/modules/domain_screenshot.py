from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_screenshot"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        return [{
            "_entity_type": "domain",
            "_entity_value": target,
            "domain": target,
            "screenshot_url": f"https://screenshot.sh/{target}",
            "thumbnail": "N/A",
            "resolution": "N/A",
            "captured": "N/A",
        }]
