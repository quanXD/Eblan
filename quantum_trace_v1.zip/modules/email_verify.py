import dns.resolver
from modules.base import BaseModule

class Module(BaseModule):
    name = "email_verify"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        domain = target.split("@")[1] if "@" in target else target
        mx = "N/A"
        try:
            ans = dns.resolver.resolve(domain, "MX")
            mx = str(ans[0].exchange)
        except:
            pass
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "format_valid": "Yes",
            "mx_record": mx,
            "smtp_check": "N/A",
            "disposable": "No",
            "role": "Yes" if target.split("@")[0] in ["admin", "support", "info", "contact", "help"] else "No",
            "domain": domain,
        }]
