from modules.base import BaseModule

class Module(BaseModule):
    name = "metadata_pdf"
    category = "metadata"
    accepts = ["url"]

    async def run(self, target):
        return [{"_entity_type": "url", "_entity_value": target, "target": target, "type": "pdf", "author": "N/A", "creator": "N/A", "created": "N/A", "source": "metadata"}]
