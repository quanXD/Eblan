import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy
from config import API_KEYS

class Module(BaseModule):
    name = "tg_messages"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        token = API_KEYS.get("telegram_bot", "")
        u = target.replace("@", "").replace("t.me/", "")
        if token:
            try:
                async with aiohttp.ClientSession() as s:
                    st, text = await fetch(s, f"https://api.telegram.org/bot{token}/getChat?chat_id=@{u}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                    if st == 200:
                        import json
                        d = json.loads(text)
                        if d.get("ok"):
                            chat = d["result"]
                            return [{
                                "_entity_type": "telegram",
                                "_entity_value": target,
                                "target": target,
                                "id": chat.get("id", "N/A"),
                                "type": chat.get("type", "N/A"),
                                "title": chat.get("title", chat.get("first_name", "N/A")),
                                "username": chat.get("username", "N/A"),
                                "members": chat.get("member_count", "N/A"),
                                "description": chat.get("description", "N/A"),
                                "method": "bot_api",
                            }]
            except:
                pass
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "status": "No bot token configured",
            "method": "bot_api",
            "note": "Set TG_BOT_TOKEN env var for live data",
        }]
