import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "tg_user"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = target.replace("@", "").replace("t.me/", "")
        url = f"https://t.me/{u}"
        result = {
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "type": "user",
            "url": url,
            "exists": "Unknown",
            "name": "N/A",
            "bio": "N/A",
            "photo": "N/A",
            "last_seen": "N/A",
            "premium": "N/A",
        }
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    if "tgme_page_title" in text or "tgme_username" in text:
                        result["exists"] = "Yes"
                        if " Premium" in text or "premium" in text.lower():
                            result["premium"] = "Yes"
                        else:
                            result["premium"] = "No"
                        if "tgme_page_photo_image" in text:
                            result["photo"] = "Yes"
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        if m:
                            result["name"] = m.group(1).strip()
                        m2 = re.search(r'<div class="tgme_page_extra">([^<]+)</div>', text)
                        if m2:
                            result["bio"] = m2.group(1).strip()
                    elif "tgme_action_button_new" not in text and "If you have Telegram, you can contact" not in text:
                        result["exists"] = "No"
                    else:
                        result["exists"] = "Yes (limited)"
        except Exception as e:
            result["error"] = str(e)
        return [result]
