import dns.resolver
from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_dns"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        results = []
        for rtype in ["A", "AAAA", "MX", "TXT", "NS", "SOA", "CNAME"]:
            try:
                ans = dns.resolver.resolve(target, rtype)
                for rdata in ans:
                    val = str(rdata)
                    results.append({"domain": target, "type": rtype, "value": val, "ttl": ans.rrset.ttl})
                    if rtype == "A":
                        results[-1]["_entity_type"] = "ip"
                        results[-1]["_entity_value"] = val
                    elif rtype == "MX":
                        mx_domain = val.split()[-1] if " " in val else val
                        results[-1]["_entity_type"] = "domain"
                        results[-1]["_entity_value"] = mx_domain
            except:
                pass
        if not results:
            results = [{"domain": target, "type": "A", "value": "N/A", "ttl": "N/A"}]
        return results
