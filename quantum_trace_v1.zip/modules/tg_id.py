from modules.base import BaseModule

class Module(BaseModule):
    name = "tg_id"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "user_id": "Requires MTProto or bot API",
            "resolved": "No",
            "method": "mtproto",
        }]
