from modules.base import BaseModule

class Module(BaseModule):
    name = "archive_is"
    category = "archive"
    accepts = ["domain", "url"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "target": target, "snapshots": "N/A", "url": f"https://archive.is/{target}", "source": "archive.is"}]
