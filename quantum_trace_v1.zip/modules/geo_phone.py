from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_phone"
    category = "geo"
    accepts = ["phone"]

    async def run(self, target):
        return [{"_entity_type": "phone", "_entity_value": target, "target": target, "type": "phone", "country": "N/A", "region": "N/A", "city": "N/A", "carrier": "N/A", "source": "geo"}]
