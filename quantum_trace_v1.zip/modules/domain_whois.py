import whois
from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_whois"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        try:
            w = whois.whois(target)
            return [{
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "registrar": str(w.registrar) if w.registrar else "N/A",
                "created": str(w.creation_date) if w.creation_date else "N/A",
                "expires": str(w.expiration_date) if w.expiration_date else "N/A",
                "updated": str(w.updated_date) if w.updated_date else "N/A",
                "name_servers": ", ".join(w.name_servers) if w.name_servers else "N/A",
                "status": ", ".join(w.status) if w.status else "N/A",
                "source": "whois",
            }]
        except:
            return [{
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "registrar": "N/A",
                "created": "N/A",
                "expires": "N/A",
                "updated": "N/A",
                "name_servers": "N/A",
                "status": "N/A",
                "source": "failed",
            }]
