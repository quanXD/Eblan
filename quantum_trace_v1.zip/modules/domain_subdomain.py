import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "domain_subdomain"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        found = []
        try:
            async with aiohttp.ClientSession() as s:
                status, text = await fetch(s, f"https://crt.sh/?q=%.{target}&output=json", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if status == 200:
                    import json
                    d = json.loads(text)
                    seen = set()
                    for entry in d[:30]:
                        name = entry.get("name_value", "").strip()
                        if name and name not in seen:
                            seen.add(name)
                            found.append({"domain": target, "subdomain": name, "source": "crt.sh"})
                    if found:
                        return found
        except:
            pass
        subs = ["www", "mail", "ftp", "api", "dev", "staging", "admin", "blog", "shop", "vpn", "cdn", "img", "static", "app", "m", "support", "help", "docs", "status", "git", "test", "demo", "portal", "secure", "api-v2", "cdn2", "static2"]
        for sub in subs:
            found.append({"domain": target, "subdomain": f"{sub}.{target}", "source": "dictionary"})
        return found
