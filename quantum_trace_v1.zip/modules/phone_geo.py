from modules.base import BaseModule

class Module(BaseModule):
    name = "phone_geo"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "country": "Russia",
            "region": "Moscow",
            "city": "Moscow",
            "coordinates": "55.7558, 37.6173",
            "timezone": "Europe/Moscow",
            "carrier": "MTS",
            "mcc": "250",
            "mnc": "01",
        }]
