from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_reverse"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "ptr_record": "N/A",
            "domains_on_ip": "N/A",
            "total_domains": "N/A",
        }]
