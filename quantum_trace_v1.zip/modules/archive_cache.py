from modules.base import BaseModule

class Module(BaseModule):
    name = "archive_cache"
    category = "archive"
    accepts = ["domain", "url"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "target": target, "cached": "N/A", "url": f"https://webcache.googleusercontent.com/search?q=cache:{target}", "source": "google_cache"}]
