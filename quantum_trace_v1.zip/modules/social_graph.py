from modules.base import BaseModule

class Module(BaseModule):
    name = "social_graph"
    category = "social"
    accepts = ["username", "email"]

    async def run(self, target):
        return [{"_entity_type": "username", "_entity_value": target, "target": target, "connections": "N/A", "common_friends": "N/A", "method": "api", "source": "social"}]
