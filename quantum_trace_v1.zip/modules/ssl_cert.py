from modules.base import BaseModule

class Module(BaseModule):
    name = "ssl_cert"
    category = "ssl"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "target": target, "subject": "N/A", "issuer": "N/A", "san": "N/A", "expiry": "N/A", "tls": "N/A", "source": "ssl"}]
