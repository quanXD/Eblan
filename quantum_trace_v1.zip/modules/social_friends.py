from modules.base import BaseModule

class Module(BaseModule):
    name = "social_friends"
    category = "social"
    accepts = ["username", "email"]

    async def run(self, target):
        return [{"_entity_type": "username", "_entity_value": target, "target": target, "friends": "N/A", "followers": "N/A", "method": "api", "source": "social"}]
