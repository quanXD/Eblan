# QuantumTrace v1.0

The God of OSINT. Modular reconnaissance framework.

## Install

```bash
pip install -r requirements.txt
python main.py
```

## Menu

```
[1] 📱 Phone
[2] 🗺️ IP Address
[3] 🌐 Domain
[4] 📧 Email
[5] 👤 Username
[6] ✈️ Telegram
[7] 🔱 Full Recon
[8] ⚙️  Settings
[9] 📊 History
[0] 🚪 Exit
```

## Features

- 116+ modules with real API integrations
- SQLite database for persistent scan history
- Automatic chain enrichment (find email → run email modules)
- Correlator: auto-links domain→IP, email→domain
- D3.js interactive graph in HTML reports
- Proxy rotation with retry + exponential backoff
- Target-type filtering: no more mixed reports

## API Keys

Set environment variables for live data:
SHODAN_KEY, VT_KEY, HUNTER_KEY, TG_BOT_TOKEN, GITHUB_KEY, NUMVERIFY_KEY, IPINFO_KEY, ABUSEIPDB_KEY, HIBP_KEY, DEHASHED_KEY, CENSYS_ID, CENSYS_SECRET

## Reports

Auto-saved to ./reports/ as JSON and HTML with D3.js graph.
