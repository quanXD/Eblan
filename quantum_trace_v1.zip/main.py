#!/usr/bin/env python3
import sys
import asyncio
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from core.ui import QuantumUI
from core.engine import QuantumEngine
from core.logger import setup_logger
from core.reporter import Reporter
from core.db import QuantumDB
from config import SEARCH_MODES

log = setup_logger()

class QuantumTrace:
    def __init__(self):
        self.ui = QuantumUI()
        self.engine = QuantumEngine()

    async def run_mode(self, mode_key):
        mode = SEARCH_MODES.get(mode_key)
        if not mode:
            self.ui.alert("Invalid mode.", "danger")
            return
        target = self.ui.ask_target(mode["name"])
        if not target:
            self.ui.alert("No target provided.", "danger")
            return
        self.ui.alert(f"\nLaunching recon for {mode['name']} target: {target}", "info")
        results = await self.engine.run_mode(mode_key, target)
        self._display(results)
        reporter = Reporter(self.engine.scan_id)
        paths = {}
        try:
            paths["JSON"] = reporter.save_json(target, mode["name"])
        except Exception as e:
            log.error(f"JSON save error: {e}")
        try:
            paths["HTML"] = reporter.save_html(target, mode["name"])
        except Exception as e:
            log.error(f"HTML save error: {e}")
        corrs = len(self.engine.db.get_correlations(self.engine.scan_id))
        self.ui.final_stats(self.engine.stats, paths, corrs)

    def _display(self, results):
        for mod_name, items in results.items():
            if not items:
                continue
            cols = list(items[0].keys()) if items else []
            self.ui.result_table(f"[{mod_name}] {len(items)} result(s)", items, cols)

    def settings(self):
        self.ui.c.print("\n[bold]Settings[/]")
        self.ui.c.print("Edit config.py to set API keys, threads, timeout, chain depth.")
        self.ui.c.print("Environment variables: SHODAN_KEY, VT_KEY, HUNTER_KEY, TG_BOT_TOKEN, GITHUB_KEY, NUMVERIFY_KEY, IPINFO_KEY, ABUSEIPDB_KEY, HIBP_KEY, DEHASHED_KEY, CENSYS_ID, CENSYS_SECRET")

    def history(self):
        db = QuantumDB()
        scans = db.get_scans()
        if not scans:
            self.ui.c.print("\n[dim]No scan history found.[/]")
            return
        from rich.table import Table
        t = Table(title="Scan History")
        t.add_column("ID")
        t.add_column("Target")
        t.add_column("Mode")
        t.add_column("Started")
        t.add_column("Finished")
        t.add_column("Stats")
        for s in scans:
            t.add_row(str(s.get("id", "")), s.get("target", ""), s.get("mode", ""), s.get("started", ""), s.get("finished", ""), s.get("stats", "")[:50])
        self.ui.c.print(t)

    async def run(self):
        self.ui.banner()
        while True:
            choice = self.ui.main_menu()
            if choice in SEARCH_MODES:
                await self.run_mode(choice)
            elif choice == "8":
                self.settings()
            elif choice == "9":
                self.history()
            elif choice == "0":
                self.ui.c.print("\n[bold red]QuantumTrace v1.0 terminated.[/]\n")
                break
            else:
                self.ui.alert("Invalid option.", "danger")

if __name__ == "__main__":
    try:
        app = QuantumTrace()
        asyncio.run(app.run())
    except KeyboardInterrupt:
        print("\n\n[!] Interrupted by user.")
        sys.exit(0)
